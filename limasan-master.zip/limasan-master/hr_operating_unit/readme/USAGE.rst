Add the operating unit to Employee
