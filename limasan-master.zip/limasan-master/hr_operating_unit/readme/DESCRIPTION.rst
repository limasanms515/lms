This module introduces the following features:

* Adds the Operating Unit (OU) to the Employee.

* The Employees's default Operating Unit (OU) is proposed at the time of creation
  getting it from the logged user.
