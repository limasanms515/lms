* The *General Ledger*, *Aged Partner Balance* reports do not support the
  filter by Operating Unit. Basically due to lack of proper hooks in the
  standard methods used by these reports, to introduce the ability to filter
  by Operating Unit.
* Trial Balance, P&L and Balance Sheet were removed from Odoo Community. Once
  OCA Financial Reports are migrated to 13 we can add the Operating Unit to
  those reports.
