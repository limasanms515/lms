#. Create a Product: the Default Operating Unit of the user is assigned to it.
   If you want, you can change to another Operating Unit.
#. Assignment of an operating unit of another company to the one set in the
   product raises an error for a multi-company setting.
#. Access rules allow to just show those products having the same operating
   units as the user
