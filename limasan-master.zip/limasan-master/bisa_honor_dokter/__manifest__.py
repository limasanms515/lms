# coding: utf-8
#
{
    "name": "Honor Dokter",
    'version': '1.0',
    'author': 'Bisa Indonesia',
    'category': 'Sales',
    "data": [
        'security/ir.model.access.csv',
        'view/menu.xml',
        'view/parameter_harga.xml',
        'view/rs_honor_dokter.xml',
        'view/hari_libur.xml',
        'view/parameter_produk.xml',
     ],
    'depends': ['base', 'product', 'account', 'purchase','bisa_hospital'],
    "test": [],
    "js": [],
    "css": [],
    "qweb": [],
    "installable": True,
    "auto_install": False,
}
