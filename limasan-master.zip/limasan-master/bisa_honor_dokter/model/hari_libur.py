# coding: utf-8
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, AccessError
from odoo import api, fields, models
from odoo.exceptions import ValidationError
import datetime
from datetime import date
from datetime import datetime, timedelta, time
from dateutil.relativedelta import relativedelta
import calendar
import pandas as pd

import base64  # file encode
from urllib.request import urlopen

class BisaInvoiceHonor(models.Model):
    _inherit = "account.move"

    get_honor = fields.Boolean('Get Honor')


 
class tbl_hari_besar(models.Model):
    _name = "tbl_hari_besar"

    name = fields.Float('Tahun')
    detail = fields.One2many('tbl_hari_besar_detail','details','Detail')

class tbl_hari_besar_detail(models.Model):
    _name = "tbl_hari_besar_detail"
    _order = "tanggal"

    details = fields.Many2one('tbl_hari_besar','Detail')
    name = fields.Char('Nama')
    tanggal = fields.Date('Tanggal')
    is_rawat_inap = fields.Boolean('Rawat Inap',readonly=True)









