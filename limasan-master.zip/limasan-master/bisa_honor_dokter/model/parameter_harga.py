# coding: utf-8
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, AccessError
from odoo import api, fields, models
from odoo.exceptions import ValidationError
import datetime
from datetime import date
from datetime import datetime, timedelta, time
from dateutil.relativedelta import relativedelta
import calendar
import pandas as pd

import base64  # file encode
from urllib.request import urlopen
 


class tbl_parameter_harga_honor_dokter_rs(models.Model):
    _name = "tbl_parameter_harga_honor_dokter_rs"

    name = fields.Char('Nama', default="/")

    shift = fields.Selection([
        ('0', 'Blank'),
        ('1', 'Satu'),
        ('2', 'Dua'),
        ('3', 'Tiga'),
        ], string='Shift')

    opsi_hari = fields.Selection([
        ('all', 'Semua'),
        ('hari_kerja', 'Hari Kerja'),
        ('hari_libur', 'Hari Libur'),
        ], string='Tipe Hari', default='all')     
    opsi_layanan = fields.Selection([
        ('all', 'Semua'),
        ('perlayanan', 'Perlayanan'),
        ], string='Pilihan Layanan', default='all')
    layanan = fields.Many2one('tbl_layanan', 'Layanan')
    opsi_produk = fields.Selection([
        ('all', 'Semua'),
        ('perproduk', 'Per Produk'),
        ], string='Pilihan Produk', default='all')
    produk = fields.Many2one('product.product', 'Product')
    opsi_formula = fields.Selection([
        ('persen', 'Persen'),
        ('fix_rp', 'Value'),
        ('formula', 'Formula'),
        ], string='Pilihan Formula', default='persen')
    formula = fields.Char('Formula')
    opsi_penjamin = fields.Selection([
        ('all', 'Semua'),
        ('per_penjamin', 'Per Penjamin'),
        ], string='Pilihan Penjamin', default='all')
    penjamin = fields.Many2one('tbl_penjamin','Penjamin')
    pot_admin= fields.Float('Admin', default=7000)
    opsi_bahan = fields.Selection([
        ('persen', 'Persen'),
        ('value', 'Value'),
        ], string='OPsi Bahan', default='persen')
    pot_bahan_persen = fields.Float('Bahan (%)')
    pot_bahan_value = fields.Float('Bahan Value')
    hak_dokter = fields.Float('Hak Dokter Value')
    hak_dokter_formula = fields.Float('Hak Dokter Formula')
    hak_dokter_persen = fields.Float('Hak Dokter (%)') 
    hak_rs = fields.Float('Hak RS')


