# coding: utf-8
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, AccessError
from odoo import api, fields, models
from odoo.exceptions import ValidationError
import datetime
from datetime import date
from datetime import datetime, timedelta, time
from dateutil.relativedelta import relativedelta
import calendar
import numpy as np
import pandas as pd

import base64  # file encode
from urllib.request import urlopen

class BisaInvoiceHonor(models.Model):
	_inherit = "account.move"

	get_honor = fields.Boolean('Get Honor')


 
class tbl_rs_honor_dokter(models.Model):
	_name = "tbl_rs_honor_dokter"
	_order = "waktu desc"

	waktu = fields.Datetime('Tanggal',readonly=True, default=lambda *a: datetime.now())
	name = fields.Char('Nomor', default='/')
	nama_dokter = fields.Many2one('tbl_dokter','Nama Dokter')
	operating_unit_id = fields.Many2one("operating.unit","ou")
	user = fields.Many2one('res.users', string='User', default=lambda self: self.env.user, readonly=True)
	pilihan = fields.Selection([
		('all', 'Semua'),
		('perdokter', 'Dokter'),
		], string='Pilihan', default='all')
	state = fields.Selection([
		('draft', 'Draft'),
		('get', 'Get Data'),
		('done', 'Done'),
		], string='Status', readonly=True, copy=False, index=True, tracking=True, default='draft')

	tanggal = fields.Date('Tanggal Awal', default=lambda *a: datetime.now())
	tanggal_akhir = fields.Date('Tanggal Akhir', default=lambda *a: datetime.now())
	detaila_id = fields.One2many('tbl_rs_honor_detaila','detail_ids','Detail')
	data = fields.Selection([
		('harian', 'Harian'),
		('multi', 'Multi'),
		], string='Data',  default='harian')

	# get data latest PO
	def action_get_data(self):
		for rec in self:
			if rec.detaila_id:
				rec.detaila_id.unlink()
			# if rec.detaila_id:
			#    rec.detaila_id.unlink()
			data_obj= self.env['tbl_rs_honor_detaila']
			# hapus_obj = self.env['tbl_rs_honor_detaila'].search([('id', '>', 0)])
			# for hapus in hapus_obj:
			# 	hapus.unlink()
			inv = self.env['tbl_verifikasi_line']
			for w in inv:
				w.write({'get_honor': False})
			if self.pilihan == 'all':
				invoice = self.env['tbl_verifikasi_line'].search([
					# ('status_layanan', '=', 'selesai'),
					('ou', '=', rec.operating_unit_id.id),
					('payment_status', 'in', ('paid','in_payment','partial')),
					('tanggal_buat', '>=', rec.tanggal),
					('tanggal_buat', '<=', rec.tanggal_akhir),
					('get_honor', '=', False)])
			else:
				invoice = self.env['tbl_verifikasi_line'].search([
					# ('status_layanan', '=', 'selesai'),
					('ou', '=', rec.operating_unit_id.id),
					('payment_status', 'in', ('paid','in_payment','partial')),
					('tanggal_buat', '>=', rec.tanggal),
					('tanggal_buat', '<=', rec.tanggal_akhir),
					('get_honor', '=', False),
					('nama_dokter', '=', rec.nama_dokter.id)])
			if not invoice:
				raise UserError(_('Data pada Invoice by shift Tidak Ditemukan'))

			for result in invoice:
				#result.get_honor = True
				nama_unit=''
				nama_unit_s = self.env['tbl_pendaftaran'].search([('id', '=', result.pendaftaran_id.id)])
				if nama_unit_s: 
					nama_unit = nama_unit_s.jenis_layanan.name
				if result.nama_dokter:
					layan='RJ'
				jam = calendar.day_name[result.tanggal_transaksi.weekday()]
				jam_name=""
				if jam == "Sunday":
					jam_name = "Minggu"
				if jam == "Monday":
					jam_name = "Senin"
				if jam == "Tuesday":
					jam_name = "Selasa"
				if jam == "Wednesday":
					jam_name = "Rabu"
				if jam == "Thursday":
					jam_name = "Kamis"
				if jam == "Friday":
					jam_name = "Jumat"
				if jam == "Saturday":
					jam_name = "Sabtu"

				tipe_hari_r=""
				tipe_hari_s = self.env['tbl_hari_besar_detail'].search([('tanggal', '=', result.tanggal_transaksi)])

				if jam == "Sunday":
					tipe_hari_r = "Libur"

				if tipe_hari_s:
					tipe_hari_r = "Libur  " + tipe_hari_s.name

				else:
					tipe_hari_r = "Kerja"

				# shift=""
				# datetime_str = str(result.tanggal_transaksi) + ' 21:00:00'
				# datetime_object = datetime.strptime(datetime_str, '%Y-%m-%d %H:%M:%S')
				# jam_malam_start = datetime_object

				# datetime_str_end = str(result.tanggal_transaksi) + ' 07:00:00'
				# datetime_object_end = datetime.strptime(datetime_str_end, '%Y-%m-%d %H:%M:%S')
				# jam_malam_end = datetime_object_end
				# tanggal_jam1 =  result.tanggal_transaksi + timedelta(hours=7)
				# if tanggal_jam1 > jam_malam_start or tanggal_jam1 < jam_malam_end:
				#       shift = "Malam"
				# else:
				#       shift = "Siang"
				shift = result.shift
				# produk_honor = self.env['tbl_tindakan_honor_dokter_detail'].search([('name', '=', result.product.id)])
						# for ph in produk_honor:
						#     raise UserError(_(ph.name.id))
						#     if line.product_id.id != ph.name.id:
				# if not produk_honor:
				nomin=0
				bahan=0

				cari_harga = self.env['tbl_parameter_harga_honor_dokter_rs'].search([
					('produk', '=', result.product.id),
					('penjamin', '=', result.penjamin.id)], limit=1)

				if cari_harga:
					nomin=0
					bahan=0
					#raise UserError(_('produk %s layanan %s penjamin %s nomina %s persendokter %s' % (result.product.name,nama_unit_s.jenis_layanan.name,result.penjamin.name,result.sub_total, cari_harga.hak_dokter_persen)))
					# if cari_harga.opsi_formula == 'fix_rp':
					# 	nomin = cari_harga.hak_dokter
					# else:
					# 	if cari_harga.opsi_hari == 'all':
					# 		if cari_harga.opsi_bahan == 'persen':
					# 			# bahan = result.sub_total * (cari_harga.pot_bahan_persen / 100)
					# 			bahan = result.sub_total * (cari_harga.pot_bahan_persen / 100)
					# 			#raise UserError(_('total1 %s persen %s bahan %s' % (result.sub_total, cari_harga.pot_bahan_persen, bahan )))
					# 		# else:
					# 		#     bahan = cari_harga.pot_bahan_value
					# 	else:
					# 		if cari_harga.opsi_hari == 'hari_libur':
					# 			if jam == 'Sunday' or tipe_hari_s:
					# 				if cari_harga.opsi_bahan == 'persen':
					# 				#     bahan = result.sub_total * (cari_harga.pot_bahan_persen / 100)
					# 				# else:
					# 					bahan = result.sub_total * (cari_harga.pot_bahan_persen / 100)
					# 					#raise UserError(_('total2 %s persen %s bahan %s' % (result.sub_total, cari_harga.hak_dokter_persen, bahan )))
					# 		else:
					# 			if cari_harga.opsi_hari == 'hari_kerja':
					# 				if jam != 'Sunday' or not tipe_hari_s:
					# 					if cari_harga.opsi_bahan == 'persen':
					# 					#     bahan = result.sub_total * (cari_harga.pot_bahan_persen / 100)
					# 					# else:
					# 						bahan = result.sub_total * (cari_harga.pot_bahan_persen / 100)
					# 						#raise UserError(_('total3%s persen %s bahan %s' % (result.sub_total, cari_harga.hak_dokter_persen, bahan )))

					# 	nomin = (result.sub_total - bahan - cari_harga.pot_admin ) * (cari_harga.hak_dokter_persen/100)
					bahan = result.sub_total * (cari_harga.pot_bahan_persen / 100) 
					nomin = (result.sub_total - bahan - cari_harga.pot_admin ) * (cari_harga.hak_dokter_persen/100)

				# else:
				#     raise UserError(_('tidak ketemu'))
				
				# cari_harga = self.env['tbl_parameter_harga_honor_dokter_rs'].search([('produk', '=', result.product.id),('layanan', '=', nama_unit_s.jenis_layanan.id),('opsi_penjamin', '=', 'all')], limit=1)
				# if cari_harga:
				#         if cari_harga.opsi_formula == 'fix_rp':
				#             nomin = cari_harga.hak_dokter
				#         else:
				#             if cari_harga.opsi_hari == 'all':
				#                 if cari_harga.opsi_bahan == 'persen':
				#                     bahan = result.sub_total * (cari_harga.pot_bahan_persen / 100)
				#                 else:
				#                     bahan = cari_harga.pot_bahan_value
				#             else:
				#                 if cari_harga.opsi_hari == 'hari_libur':
				#                     if jam == 'Sunday' or tipe_hari_s:
				#                         if cari_harga.opsi_bahan == 'persen':
				#                             bahan = result.sub_total * (cari_harga.pot_bahan_persen / 100)
				#                         else:
				#                             bahan = cari_harga.pot_bahan_value
				#                 else:
				#                     if cari_harga.opsi_hari == 'hari_kerja':
				#                         if jam != 'Sunday' or not tipe_hari_s:
				#                             if cari_harga.opsi_bahan == 'persen':
				#                                 bahan = result.sub_total * (cari_harga.pot_bahan_persen / 100)
				#                             else:
				#                                 bahan = cari_harga.pot_bahan_value

				#             nomin = result.sub_total - (result.sub_total - bahan - cari_harga.pot_admin )

				# cari_harga = self.env['tbl_parameter_harga_honor_dokter_rs'].search([('produk', '=', result.product.id),('opsi_layanan', '=', 'all'),('penjamin', '=', result.penjamin.id)], limit=1)
				# if cari_harga:
				#         if cari_harga.opsi_formula == 'fix_rp':
				#             nomin = cari_harga.hak_dokter
				#         else:
				#             if cari_harga.opsi_hari == 'all':
				#                 if cari_harga.opsi_bahan == 'persen':
				#                     bahan = result.sub_total * (cari_harga.pot_bahan_persen / 100)
				#                 else:
				#                     bahan = cari_harga.pot_bahan_value
				#             else:
				#                 if cari_harga.opsi_hari == 'hari_libur':
				#                     if jam == 'Sunday' or tipe_hari_s:
				#                         if cari_harga.opsi_bahan == 'persen':
				#                             bahan = result.sub_total * (cari_harga.pot_bahan_persen / 100)
				#                         else:
				#                             bahan = cari_harga.pot_bahan_value
				#                 else:
				#                     if cari_harga.opsi_hari == 'hari_kerja':
				#                         if jam != 'Sunday' or not tipe_hari_s:
				#                             if cari_harga.opsi_bahan == 'persen':
				#                                 bahan = result.sub_total * (cari_harga.pot_bahan_persen / 100)
				#                             else:
				#                                 bahan = cari_harga.pot_bahan_value

				#             nomin = result.sub_total - (result.sub_total - bahan - cari_harga.pot_admin )

				# cari_harga = self.env['tbl_parameter_harga_honor_dokter_rs'].search([('produk', '=', result.product.id),('opsi_layanan', '=', 'all'),('opsi_penjamin', '=', 'all')], limit=1)
				# if cari_harga:
				#         if cari_harga.opsi_formula == 'fix_rp':
				#             nomin = cari_harga.hak_dokter
				#         else:
				#             if cari_harga.opsi_hari == 'all':
				#                 if cari_harga.opsi_bahan == 'persen':
				#                     bahan = result.sub_total * (cari_harga.pot_bahan_persen / 100)
				#                 else:
				#                     bahan = cari_harga.pot_bahan_value
				#             else:
				#                 if cari_harga.opsi_hari == 'hari_libur':
				#                     if jam == 'Sunday' or tipe_hari_s:
				#                         if cari_harga.opsi_bahan == 'persen':
				#                             bahan = result.sub_total * (cari_harga.pot_bahan_persen / 100)
				#                         else:
				#                             bahan = cari_harga.pot_bahan_value
				#                 else:
				#                     if cari_harga.opsi_hari == 'hari_kerja':
				#                         if jam != 'Sunday' or not tipe_hari_s:
				#                             if cari_harga.opsi_bahan == 'persen':
				#                                 bahan = result.sub_total * (cari_harga.pot_bahan_persen / 100)
				#                             else:
				#                                 bahan = cari_harga.pot_bahan_value

				#             nomin = result.sub_total - (result.sub_total - bahan - cari_harga.pot_admin )


				data = data_obj.create({
										   'detail_ids': rec.id,
										   'pot_admin': cari_harga.pot_admin,
										   'pot_bahan': bahan,
										   'no_reg': result.pendaftaran_id.id,
										   'no_invoice': result.invoice_id.name,
										   'nama_dokter': result.nama_dokter.name,
										   'name': result.partner.name,
										   'penjamin': result.penjamin.name,
										   'tipe_penjamin': result.penjamin.tipe_penjamin1.name,
										   'tanggal': result.tanggal_transaksi,
										   'tanggal_awal': result.tanggal_buat,
										   'jasa_medis_tindakan': result.product.name,
										   'produk': result.product.id,
										   'layanan': result.invoice_id.unit_layanan__.name,
										   'hari': jam_name,
										   'tipe_hari': tipe_hari_r,
										   'nominal_dokter': nomin,
										   'nominal': result.sub_total,
										   # 'nominal': result.sub_total,
										   'shift': shift,
										   'unit': nama_unit,
										})
					

	# get data latest PO
	def action_hitung(self):
		for line in self.detaila_id:
			penjamin = self.env['tbl_penjamin'].search([('name','=', line.penjamin)])
			if line.tipe_hari == 'Kerja':
				hari = 'hari_kerja'
			else:
				hari = 'hari_libur'
			parm = self.env['tbl_parameter_harga_honor_dokter_rs'].search([])
			nomor = ['1','2','3']
			blank = [l.shift if l.shift not in nomor else '0' for l in parm]
			obj = parm.filtered(lambda l: l.produk.id == line.produk.id and l.penjamin.id == penjamin.id and l.opsi_hari == hari and l.shift == line.shift or l.produk.id == line.produk.id and l.penjamin.id == penjamin.id and l.opsi_hari == hari and l.shift in blank or l.produk.id == line.produk.id and l.opsi_penjamin == 'all' and l.opsi_hari == hari and l.shift in blank or l.produk.id == line.produk.id and l.opsi_penjamin == 'all' and l.opsi_hari == hari and l.shift == line.shift)	
			for ls in obj:
				nominal = line.nominal
				bahan = ls.pot_bahan_persen
				dokter = ls.hak_dokter_persen
				admin = ls.pot_admin
				bhn = nominal - admin
				sub_bahan = bhn * (bahan/100)
				total = bhn - sub_bahan
				nominal_dokter = total * (dokter/100)
				if ls.opsi_formula == 'fix_rp':
					line.nominal_dokter = ls.hak_dokter
				else:
					line.nominal_dokter = nominal_dokter






				# if ls.pot_admin == 0:
				# 	if ls.opsi_bahan == 'persen':
				# 		sub_bahan = np.percentile(nominal, bahan)
				# 	else:
				# 		sub_bahan = ls.pot_bahan_value
				# 	bhn = sub_bahan
				# else:
				# 	bhn = nominal - ls.pot_admin
				
				# if ls.opsi_formula == 'persen':
				# 	sub_dokter = np.percentile(bhn, dokter)
				# 	line.nominal_dokter = (nominal - bhn) * sub_dokter
				# 	print(nominal,'nominal')
				# 	print(sub_dokter,'sub_dokter')
				# 	print(line.nominal_dokter,'nominal_dokter')
				# else:
				# 	sub_dokter = ls.hak_dokter
				# 	line.nominal_dokter = sub_dokter




		# for rec in self:
		# 	parm = self.env['tbl_parameter_harga_honor_dokter_rs'].search([])
		# 	prod = parm.filtered(lambda l: l.produk.name[:2] == 'T.')
		# 	for line in prod:
		# 		for data in rec.detaila_id:
				
				# produk_hitung = self.env['tbl_parameter_harga_honor_dokter_rs'].search([
				# 	('produk', '=', data.produk.id),
				# 	('shift', '=','3')], limit=1)           
				# produk_hitung = self.env['tbl_parameter_harga_honor_dokter_rs'].search([('produk', '=', data.produk.id), ('penjamin', '=', rec.penjamin.id)], limit=1)           
				# penjamin = self.env['tbl_penjamin'].search([('name', '=', data.penjamin)], limit=1)           
				# produk_hitung = self.env['tbl_parameter_harga_honor_dokter_rs'].search([
				# 	('produk', '=', data.produk.id), 
				# 	('penjamin', '=', penjamin.id)], limit=1)           
					# if data.opsi_formula == 'fix_rp':
					# 	data.nominal_dokter = 15000
				# if produk_hitung.opsi_formula == 'fix':
				#    data.nominal_dokter = (produk_hitung.hak_dokter/100) * data.nominal
					# doc = False
					# obj = False
					# if line.produk == data.produk and data.shift == "3" and line.shift == '3':
					# 	data.nominal_dokter = (75/50) * data.nominal_dokter
					# 	doc = True
					# elif line.produk == data.produk and data.tipe_hari != 'Kerja':
					# 	# data.nominal_dokter = (line.produk.lst_price * (1 - line.pot_bahan_persen/100)) * (line.hak_dokter_persen/100)
					# 	data.nominal_dokter = (data.nominal * (1 - line.pot_bahan_persen/100)) * (line.hak_dokter_persen/100)
					# 	obj = True
					# elif line.opsi_formula == 'fix_rp' and not doc and not obj:
					# 	data.nominal_dokter = line.hak_dokter






class tbl_rs_honor_detaila(models.Model):
	_name = "tbl_rs_honor_detaila"
	_order = "tanggal, nama_dokter, unit"

	detail_ids = fields.Many2one('tbl_rs_honor_dokter','Detail')
	tanggal = fields.Datetime('Tanggal Transaksi',readonly=True)
	tanggal_awal = fields.Date('Tanggal Awal', related='detail_ids.tanggal', store=True)
	pot_admin= fields.Float('Admin', default=7000,readonly=True)
	pot_bahan= fields.Float('Bahan',readonly=True)
	no_reg = fields.Char('No Registrasi',readonly=True)
	no_invoice = fields.Char('No Invoice',readonly=True)
	nama_dokter = fields.Char('Nama Dokter')
	name = fields.Char('Pasien',readonly=True)
	penjamin = fields.Char('Penjamin')
	tipe_penjamin = fields.Char('Tipe Penjamin')
	hari = fields.Char('Nama Hari',readonly=True)
	tipe_hari = fields.Char('Tipe Hari',readonly=True)
	shift = fields.Char('Shift',readonly=True)
	layanan = fields.Char('Layanan')
	unit = fields.Char('Unit')
	jasa_medis_tindakan = fields.Char('Jasa/Tindakan')
	produk = fields.Many2one('product.product', 'Produk')
	nominal = fields.Float('Nominal',readonly=True)
	nominal_dokter = fields.Float('Hak Dokter')

class tbl_rs_honor_move(models.Model):
	_inherit = "account.move"

	get_honor = fields.Float('Get Honor',readonly=True)
	is_rawat_inap = fields.Boolean('Rawat Inap',readonly=True)











