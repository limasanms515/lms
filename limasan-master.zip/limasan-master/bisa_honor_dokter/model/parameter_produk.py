# coding: utf-8
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, AccessError
from odoo import api, fields, models
from odoo.exceptions import ValidationError
import datetime
from datetime import date
from datetime import datetime, timedelta, time
from dateutil.relativedelta import relativedelta
import calendar
import pandas as pd

import base64  # file encode
from urllib.request import urlopen

class tbl_tindakan_honor_dokter(models.Model):
    _name = "tbl_tindakan_honor_dokter"

    name = fields.Char('Nama')
    detail = fields.One2many('tbl_tindakan_honor_dokter_detail','details','Detail')

class tbl_tindakan_honor_dokter_detail(models.Model):
    _name = "tbl_tindakan_honor_dokter_detail"

    details = fields.Many2one('tbl_tindakan_honor_dokter','Detail')
    name = fields.Many2one('product.product','Nama')
    rapid = fields.Selection([
        ('injeksi', 'Injeksi'),
        ('pemeriksaan', 'Pemeriksaan'),
        ('rapid', 'Rapid'),
        ('tindakan', 'Tindakan/Jasa Medis'),
        ('tidak', 'Tidak Ada'),
        ], string='Kategori Tindakan',  default='tidak')

    dokter = fields.Selection([
        ('gigi', 'Gigi'),
        ('umum', 'Umum'),
        ], string='Layanan Dokter',  default='umum')









