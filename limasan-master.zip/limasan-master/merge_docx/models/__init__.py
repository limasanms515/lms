# -*- coding: utf-8 -*-
##############################################################################
# For copyright and license notices, see __manifest__.py file in root directory
##############################################################################
# flake8: NOQA
from . import partner
from . import company
from . import report
