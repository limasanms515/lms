
Pre-Installation Requirements (Convert to PDF)
-----------------------------

- **Unoconv**: Convert files to any format that supports Microsoft Office. Website: `Unoconv <http://dag.wiee.rs/home-made/unoconv/>`_ example install ubuntu O.S. 


# apt-get install unoconv


Supported output format combinations (Template -> Output):

- odt -> odt
- odt -> pdf
- odt -> doc
- odt -> docx
- odt -> pds
- rtf -> rtf
- docx -> pdf

Note
----
Fully Supports Odoo Version 13.0 Community

