# -*- coding: utf-8 -*-
##############################################################################
# For copyright and license notices, see __manifest__.py file in root directory
##############################################################################
# flake8: NOQA
from . import models
from . import controllers

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
