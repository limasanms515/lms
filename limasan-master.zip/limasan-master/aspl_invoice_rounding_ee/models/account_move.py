# -*- coding: utf-8 -*-
#################################################################################
# Author      : Acespritech Solutions Pvt. Ltd. (<www.acespritech.com>)
# Copyright(c): 2012-Present Acespritech Solutions Pvt. Ltd.
# All Rights Reserved.
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
#
#################################################################################

from odoo import models, fields, api, _
from odoo.exceptions import Warning
from odoo.exceptions import RedirectWarning, UserError, ValidationError
from lxml import etree
import math


class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'

    rounding_move_line = fields.Boolean(string="Rounding Move Line", copy=False, )


class AccountMove(models.Model):
    _inherit = "account.move"

    round_off = fields.Float(string="Round Off", copy=False)
    value = 0.0

    @api.depends('invoice_line_ids','invoice_line_ids.tax_ids','invoice_line_ids.price_subtotal')
    def compute_roundup(self):
        self.round_off = (round(float(self.amount_untaxed + self.amount_tax) / 500) * 500) - (self.amount_untaxed + self.amount_tax)


    @api.model
    def fields_view_get(self, view_id=None, view_type=False, toolbar=False, submenu=False):
        res = super(AccountMove, self).fields_view_get(view_id=view_id, view_type=view_type, toolbar=toolbar,
                                                       submenu=submenu)
        if view_type == 'form':
            enable_invoice_rounding = self.env['ir.config_parameter'].sudo().get_param('enable_invoice_amount_rounding')
            if not enable_invoice_rounding:
                doc = etree.XML(res['arch'])
                if doc.xpath("//button[@name='apply_round_off']"):
                    node = doc.xpath("//button[@name='apply_round_off']")[0]
                    node.set('invisible', '1')
                if doc.xpath("//label[@for='round_off']"):
                    node = doc.xpath("//label[@for='round_off']")[0]
                    node.set('invisible', '1')
                if doc.xpath("//field[@name='round_off']"):
                    node = doc.xpath("//field[@name='round_off']")[0]
                    node.set('invisible', '1')
                if doc.xpath("//button[@name='remove_round_off']"):
                    node = doc.xpath("//button[@name='remove_round_off']")[0]
                    node.set('invisible', '1')
                res['arch'] = etree.tostring(doc)
        return res

    def remove_round_off(self):
        self.round_off = 0.00

    def apply_round_off(self):

        def roundup(x):
            return int(math.ceil(x / 500.0)) * 500
        invoice_line_list = []
        params = self.env['ir.config_parameter'].sudo()
        total_amount = round_off_value = 0.00
        total_amount = self.amount_untaxed + self.amount_tax
        enable_invoice_rounding = bool(params.get_param('enable_invoice_amount_rounding')),
        if enable_invoice_rounding:
            rounding_option = params.get_param('rounding_option')
            round_off_value = round(total_amount) if rounding_option == 'digits' else round(total_amount / 1, 1)
            #self.round_off = (round_off_value - total_amount)
            self.round_off = roundup(float(self.amount_untaxed + self.amount_tax)) - (self.amount_untaxed + self.amount_tax)


    @api.depends('line_ids.matched_debit_ids.debit_move_id.move_id.payment_id.is_matched',
                 'line_ids.matched_debit_ids.debit_move_id.move_id.line_ids.amount_residual',
                 'line_ids.matched_debit_ids.debit_move_id.move_id.line_ids.amount_residual_currency',
                 'line_ids.matched_credit_ids.credit_move_id.move_id.payment_id.is_matched',
                 'line_ids.matched_credit_ids.credit_move_id.move_id.line_ids.amount_residual',
                 'line_ids.matched_credit_ids.credit_move_id.move_id.line_ids.amount_residual_currency',
                 'line_ids.debit', 'line_ids.credit', 'line_ids.currency_id', 'line_ids.amount_currency',
                 'line_ids.amount_residual', 'line_ids.amount_residual_currency', 'line_ids.payment_id.state',
                 'line_ids.full_reconcile_id', 'round_off')
    def _compute_amount(self):
        super(AccountMove, self)._compute_amount()
        for move in self:
            move.amount_tax = move.amount_tax + move.round_off

    def action_post(self):
        invoice_line_list = []
        rounding_account_id = int(self.env['ir.config_parameter'].sudo().get_param('rounding_account_id'))
        tax_id = int(self.env['ir.config_parameter'].sudo().get_param('invoice_amount_rounding_tax'))
        credit = debit = 0.0
        self.apply_round_off()
        #raise UserError(_(tax_id))

        if not self.round_off == 0.00:
            if not rounding_account_id:
                raise Warning(_('Please select rounding account first in accounting settings.'))
            if self.round_off > 0:
                credit = self.round_off
            elif self.round_off < 0:
                debit = self.round_off
            if credit or debit:
                if self.amount_tax == 0:
                   invoice_line_list.append((0, 0, {'name': 'Pembulatan',
                                                 'account_id': rounding_account_id,
                                                 'price_unit': debit or credit,
                                                 'quantity': 1.00}))
                else:
                   invoice_line_list.append((0, 0, {'name': 'Pembulatan',
                                                 'account_id': rounding_account_id,
                                                 'price_unit': debit or credit,
                                                 'quantity': 1.00,
                                                 'tax_ids': [(4, tax_id)]}))

                self.update({
                    'invoice_date': self.invoice_date,
                    'partner_id': self.partner_id,
                    'invoice_line_ids': invoice_line_list,
                })


                for line in self.line_ids:
                    if line.account_id.id == rounding_account_id:
                        line.rounding_move_line = True

            if self.mapped('line_ids.payment_id') and any(
                    post_at == 'bank_rec' for post_at in self.mapped('journal_id.post_at')):
                raise UserError(_(
                    "A payment journal entry generated in a journal configured to post entries only when payments are reconciled with a bank statement cannot be manually posted. Those will be posted automatically after performing the bank reconciliation."))

        #if self.invoice_line_ids:
        #   for pajak in self.invoice_line_ids:
         #      if not pajak.tax_ids:
        #              pajak.tax_ids = [(4, 3073)]

        self.round_off = 0
        return self._post(soft=False)
