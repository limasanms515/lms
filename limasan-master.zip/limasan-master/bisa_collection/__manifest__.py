# coding: utf-8
#
{
    "name": "L.Collection",
    'version': '1.0',
    'author': 'Bisa Indonesia',
    'category': 'Sales',
    "data": [
        #'data/ir_sequence_data.xml',
        'security/ir.model.access.csv',
        'view/menu.xml',
        'view/collection.xml',
     ],
    'depends': ['base', 'sale', 'product', 'account'],
    "test": [],
    "js": [],
    "css": [],
    "qweb": [],
    "installable": True,
    "auto_install": False,
}
