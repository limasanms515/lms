
from odoo import models, fields, api


class ResCompanyInherit(models.Model):
    _inherit = 'res.company'


    is_cash = fields.Boolean(string="Journal Cash", defualt=False)
    account_cash_id = fields.Many2one('account.account',string="Account Cash", defualt=False)
    account_penjamin_id = fields.Many2one('account.account',string="Account Penunjang", defualt=False)
    account_poli_id = fields.Many2one('account.account',string="Account Poli", defualt=False)
    cash_journal_ids = fields.Many2many('account.journal', string="Allowed Journal")
    journal_cash_id = fields.Many2one('account.journal', string="Journal Cash")


    is_credit = fields.Boolean(string="Journal Credit", defualt=False)
    account_credit_id = fields.Many2one('account.account',string="Account Credit", defualt=False)
    account_poli_credit_id = fields.Many2one('account.account',string="Account Poli", defualt=False)
    credit_journal_ids = fields.Many2many('account.journal','account_journal_financial_credit', 'account_journal_id', 'financial_credit_id', string="Allowed Journal")
    journal_credit_id = fields.Many2one('account.journal', string="Journal Credit")


class ResConfigSettingsInherit(models.TransientModel):
    _inherit = 'res.config.settings'





    is_credit = fields.Boolean(related='company_id.is_credit', readonly=False)
    account_credit_id = fields.Many2one('account.account',related='company_id.account_credit_id', readonly=False)
    account_poli_credit_id = fields.Many2one('account.account',related='company_id.account_poli_credit_id', readonly=False)
    credit_journal_ids = fields.Many2many('account.journal','account_journal_financial_credit', 'account_journal_id', 'financial_credit_id',related="company_id.credit_journal_ids", readonly=False)
    journal_credit_id = fields.Many2one('account.journal',related="company_id.journal_credit_id", readonly=False)

    @api.onchange('is_credit')
    def change_is_cash(self):
        if not self.is_credit:
            self.account_credit_id = False
            self.account_poli_credit_id = False
            self.credit_journal_ids = False
            self.journal_credit_id = False


    is_cash = fields.Boolean(related='company_id.is_cash', readonly=False)
    account_cash_id = fields.Many2one('account.account',related='company_id.account_cash_id', readonly=False)
    account_penjamin_id = fields.Many2one('account.account',related='company_id.account_penjamin_id', readonly=False)
    account_poli_id = fields.Many2one('account.account',related='company_id.account_poli_id', readonly=False)
    cash_journal_ids = fields.Many2many('account.journal',related="company_id.cash_journal_ids", readonly=False)
    journal_cash_id = fields.Many2one('account.journal',related="company_id.journal_cash_id", readonly=False)

    @api.onchange('is_cash')
    def change_is_cash(self):
        if not self.is_cash:
            self.account_cash_id = False
            self.account_penjamin_id = False
            self.account_poli_id = False
            self.cash_journal_ids = False
            self.journal_cash_id = False
