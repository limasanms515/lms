
from odoo import models, fields, api
from datetime import date, datetime
from dateutil.relativedelta import relativedelta




class TblVerifikasiLine(models.Model):
    _inherit = 'tbl_verifikasi_line'
    _description = "Automate Journal"




    def action_create_journal(self):
        company = self.env.user.company_id
        today = fields.Date.today()
        days = today - relativedelta(days=1)
        if company.is_cash:
            verifikasi = self.search([
                ('journal_id','in',company.cash_journal_ids.ids),
                ('tanggal_buat','=',days),
                ])
            count_poli = 0
            non_poli = 0   
            for verif in verifikasi:
                unit_layanan = verif.unit_layanan.name[:4]
                if unit_layanan == 'Poli':
                    count_poli += verif.sub_total
                else:
                    non_poli += verif.sub_total  
            cash = count_poli + non_poli
            line = []
            line.append((0,0,{
                'account_id': company.account_cash_id.id,
                'name': 'CASH',
                'debit': cash,
                'credit': 0
                }))
            if non_poli > 0:
                line.append((0,0,{
                    'account_id': company.account_penjamin_id.id,
                    'name': 'CASH',
                    'debit': 0,
                    'credit': non_poli
                    }))
            if count_poli > 0:
                line.append((0,0,{
                    'account_id': company.account_poli_id.id,
                    'name': 'CASH',
                    'debit': 0,
                    'credit': count_poli
                    }))
            vals = {
                'ref': 'CASH',
                'date': days,
                'journal_id': company.journal_cash_id.id,
                'line_ids': line
            }
            if cash > 0:
                move = self.env['account.move'].create(vals)

        if company.is_credit:
            verifikasi = self.search([
                ('journal_id','in',company.credit_journal_ids.ids),
                ('tanggal_buat','=',days)
                ])
            count_poli = 0
            for verif in verifikasi:
                unit_layanan = verif.unit_layanan.name[:4]
                if unit_layanan == 'Poli':
                    count_poli += verif.sub_total
            credit = count_poli
            print(credit,'credit')
            line = []
            line.append((0,0,{
                'account_id': company.account_credit_id.id,
                'name': 'CREDIT',
                'debit': credit,
                'credit': 0
                }))
            if count_poli > 0:
                line.append((0,0,{
                    'account_id': company.account_poli_credit_id.id,
                    'name': 'CREDIT',
                    'debit': 0,
                    'credit': count_poli
                    }))
            vals = {
                'ref': 'CREDIT',
                'date': days,
                'journal_id': company.journal_credit_id.id,
                'line_ids': line
            }
            if credit > 0:
                move = self.env['account.move'].create(vals)
