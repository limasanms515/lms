{
    "name": "NGT Journal",
    "version": "14.0.1.0.0",
    "category": "Accounting",
    "website": "nusagarda.com",
    "author": "asop-source",
    "depends": ["base","account","bisa_verifikasi"],
    "data": [
        # 'security/ir.model.access.csv',
        'data/ir_cron_job.xml',
        'views/res_config.xml',
    ],
}
