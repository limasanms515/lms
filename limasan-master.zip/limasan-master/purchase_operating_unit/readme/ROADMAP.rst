Procurement Orders were removed. Procurement Operating Unit module is
deprecated. Stock Operating Unit ensures consistency between the operating unit
from different models.
