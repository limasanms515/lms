#. Create a PO: the Default Operating Unit is assigned to the PO. If you want,
   you can change to another Operating Unit.
#. Validate the PO: the Operating Unit is propagated to the Pickings and
   Invoices.
#. From the invoice, it is not possible to change the Operating Unit, it has to
   be the same as the one of the PO.
