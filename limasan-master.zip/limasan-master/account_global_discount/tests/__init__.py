from . import test_global_discount
