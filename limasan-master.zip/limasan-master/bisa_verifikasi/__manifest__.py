# coding: utf-8
#
{
    "name": "Verifikasi",
    'version': '1.0',
    'author': 'Bisa Indonesia',
    'category': 'Sales',
    "data": [
        'security/ir.model.access.csv',
        'view/menu.xml',
        'view/verifikasi.xml',

     ],
    'depends': ['base', 'product', 'account','bisa_hospital'],
    "test": [],
    "js": [],
    "css": [],
    "qweb": [],
    "installable": True,
    "auto_install": False,
}
