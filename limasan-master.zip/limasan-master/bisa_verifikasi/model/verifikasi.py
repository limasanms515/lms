# coding: utf-8
from odoo import api, fields, models, SUPERUSER_ID, _
from odoo.exceptions import UserError, AccessError
from odoo import api, fields, models
from odoo.exceptions import ValidationError
import datetime
from datetime import date
from datetime import datetime, timedelta, time
from dateutil.relativedelta import relativedelta
import calendar
import pandas as pd

import base64  # file encode
from urllib.request import urlopen
import psycopg2




 
class tbl_verifikasi(models.Model):
    _name = "tbl_verifikasi"
    # _order = "waktu desc"

    tanggal = fields.Datetime('Tanggal',readonly=True, default=lambda *a: datetime.now())
    name = fields.Char('Nama', default='Verifikasi')
    user = fields.Many2one('res.users', string='User', default=lambda self: self.env.user, readonly=True)
    tanggal_awal = fields.Date('Tanggal Awal', default=lambda *a: datetime.now())
    tanggal_akhir = fields.Date('Tanggal Akhir', default=lambda *a: datetime.now())
    detail = fields.One2many('tbl_verifikasi_line','details','Detail')
    ou = fields.Many2one('operating.unit','ou', required=True)

    state = fields.Selection(selection=[
            ('draft', 'Draft'),
            ('getdata', 'Get Data Invoice'),
            ('getlayanan', 'Get Data Layanan'),
            ('verifikasi', 'Verifikasi'),
            ('sync', 'Kirim ke LFIN'),
        ], string='Status',readonly=True, copy=False, tracking=True, default='draft')

    # get data latest PO
    def action_get_data(self):
        for rec in self:
            if rec.detail:
                rec.detail.unlink()
            data_obj= self.env['tbl_verifikasi_line']
            # hapus_obj = self.env['tbl_rs_honor_detaila'].search([('id', '>', 0)])
            # for hapus in hapus_obj:
            # 	hapus.unlink()
            serah_h = self.env['tbl_report_detail_invoice'].search([('ou_payment2', '=', rec.ou.id),('state', '=', 'serah_terima'),('date', '>=', rec.tanggal_awal),('date', '<=', rec.tanggal_akhir)])
            if not serah_h:
                raise UserError(_('Data Report Invoice by Shift tidak ditemukan'))

            for result in serah_h:
              if result.ou_payment2.id == rec.ou.id:
                #raise UserError(_(result.ou_payment2.id))
                data = data_obj.create({
                                   'details': rec.id,
                                   #'report_shift_id': result.id,
                                   'tanggal_buat': result.date,
                                   'tanggal_transaksi': result.date,
                                   'shift': result.shift.name,
                                   'ou': result.ou_payment2.id,
                                   'cash_penerimaan': result.nominal_diterima1,
                                })
                for line in result.detail_id:
                    data = data_obj.create({
                                   'details': rec.id,
                                   'report_shift_id': line.id,
                                   'tanggal_buat': result.date,
                                   'shift': result.shift.name,
                                   'ou': result.ou_payment2.id,
                                   'cash_penerimaan': 0,
                                })
            rec.action_hitung()
                

    # get data latest PO
    def action_hitung(self):
        for rec in self:
            for data in rec.detail:
                if data.pendaftaran_id:
                   self.env.cr.execute("select state, jenis_layanan, nama_dokter from  tbl_poli where no_reg = %s and tanggal_transaksi = %s", (data.pendaftaran_id.id,data.tanggal_transaksi))
                item = self.env.cr.fetchone() 
                if item:
                    print(item,'iiiiiiiiiiiiiiiiiiiiii')
                    data.unit_layanan = item[1]
                    data.status_layanan = item[0]
                    data.nama_dokter = item[2]


    def action_sync(self):
        for rec in self:
           connection = psycopg2.connect(user="integrasi",
                                  password="integrasi",
                                  host="103.65.237.94",
                                  port="5432",
                                  database="LFIN2")
           cursor = connection.cursor()
           for syn in rec.detail:
               pg_insert = "insert into tbl_verifikasi_line (invoice_id, partner, company_id, report_shift_id,penjamin, tanggal_buat, tanggal_transaksi, pendaftaran_id, product, product_category, unit_layanan, sub_total, journal_id, nama_dokter, shift, cash_penerimaan) values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"
               inserted_values = (syn.invoice_id.name or '', 
                     syn.partner.name or '', 
                     syn.ou.ou_company_id, 
                     syn.report_shift_id.name.name or '', 
                     syn.penjamin.name or '', 
                     syn.tanggal_buat, 
                     syn.tanggal_transaksi, 
                     syn.pendaftaran_id.no_registrasi or '', 
                     syn.product.name or '', 
                     syn.product_category.name or '', 
                     syn.unit_layanan.name  or '', 
                     syn.sub_total, 
                     syn.journal_id.name or '', 
                     syn.nama_dokter.name  or '', 
                     syn.shift, 
                     syn.nominal_diterima1)
               cursor.execute(pg_insert, inserted_values)
               connection.commit()


    def action_selesai(self):
        for rec in self:
            for act in rec.detail:
                act.action_verify()
            rec.state = 'verifikasi'    

    def action_selectall(self):
        for rec in self:
            for sel in rec.detail:
                sel.select = True


 
class tbl_verifikasi_line(models.Model):
    _name = "tbl_verifikasi_line"
    _order = "tanggal_buat, unit_layanan, penjamin, user_pembuat"

    details = fields.Many2one('tbl_verifikasi','Verifikasi')
    report_shift_id = fields.Many2one('tbl_report_detail_invoice_line','Kasir', store=True)
    invoice_id = fields.Many2one('account.move','Number', related='report_shift_id.move_lines.move_id', store=True)
    partner = fields.Many2one('res.partner','Partner', related='invoice_id.partner_id', store=True)
    penjamin = fields.Many2one('tbl_penjamin','Penjamin', related='invoice_id.penjamin', store=True)
    tanggal_buat = fields.Date('Tanggal Buat',readonly=True)
    tanggal_transaksi = fields.Date('Tanggal Transaksi',related='invoice_id.invoice_date', store=True)
    payment_status = fields.Selection(selection=[
        ('not_paid', 'Not Paid'),
        ('in_payment', 'In Payment'),
        ('paid', 'Paid'),
        ('partial', 'Partially Paid'), 
        ('reversed', 'Reversed'),
        ('invoicing_legacy', 'Invoicing App Legacy')],
        string="Payment Status", store=True, related='invoice_id.payment_state')
    pendaftaran_id = fields.Many2one('tbl_pendaftaran','No Registrasi', related='invoice_id.pendaftaran_id')
    user_pembuat = fields.Char('User Pembuat',readonly=True)
    # ou_payment = fields.Many2many(
    #     'operating.unit', 'operating_unit_bl_report_detail_invoice',
    #     'partner_id1', 'operating_unit_id1',
    #     'Operating Units', related='report_shift_id.operating_unit_ids')
    # ou_payment2 = fields.Many2one('operating.unit', 'Operating Units2',compute='get_ou')
    # ou_payment3 = fields.Char('Operating Units3',compute='get_ou')
    ou = fields.Many2one('operating.unit','ou', readonly=True)
    product = fields.Many2one('product.product','Nama Produk', related='report_shift_id.move_lines.product_id')
    product_category = fields.Many2one('product.category','Produk Kategori', related='product.categ_id')
    unit_layanan = fields.Many2one('tbl_layanan','Unit Layanan',readonly=True,related='invoice_id.unit_layanan__')
    sub_total = fields.Float('Sub Total', related='report_shift_id.nominal', store=True)
    status_layanan = fields.Char('Status Layanan',readonly=True)
    status_verifikasi = fields.Char('Status Verifikasi',default='draft', readonly=True)
    journal_id = fields.Many2one('account.journal','Jurnal', related='report_shift_id.journal_id', store=True)
    nama_dokter = fields.Many2one('tbl_dokter','Nama Dokter', readonly=True)
    shift = fields.Char('Shift', readonly=True)
    select = fields.Boolean(' ')
    cash_penerimaan = fields.Float('Penerimaan')
    get_honor = fields.Boolean('Honor', default=False)


    def action_verify(self):
        for rec in self:
            if rec.status_layanan != 'selesai' and rec.payment_status !='paid':
                raise UserError(_('Belum bisa di verifikasi, status pelayanan ada yg belum selesai'))
            else:
                rec.status_verifikasi = 'selesai'



    @api.depends('ou_payment')
    def get_ou(self):
        for rec in self:
            if rec.ou_payment:
                if len(rec.ou_payment) == 1:
                    rec.ou_payment3 = rec.ou_payment
                    rec.ou_payment2 = rec.ou_payment
            

class tbl_poli_verifikasi(models.Model):
    _inherit = "tbl_poli"

    tanggal_transaksi = fields.Date('Tanggal Transaksi', compute='comp_tanggal_transaksi', store=True)

    @api.depends('waktu')
    def comp_tanggal_transaksi(self):
        for rec in self:
           if rec.waktu:
               rec.tanggal_transaksi = rec.waktu 



class tbl_reportdetailinvoice_verifikasi(models.Model):
    _inherit = "tbl_report_detail_invoice"

    ou_payment2 = fields.Many2one('operating.unit', 'Operating Units2',compute='get_ou')

    @api.depends('operating_unit_ids')
    def get_ou(self):
        for rec in self:
            if rec.operating_unit_ids:
                if len(rec.operating_unit_ids) == 1:
                    rec.ou_payment2 = rec.operating_unit_ids


class tbl_operating_unit_verifikasi(models.Model):
    _inherit = "operating.unit"

    ou_company_id = fields.Integer('Company ID LFIN')





