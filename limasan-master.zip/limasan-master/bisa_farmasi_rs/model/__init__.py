# coding: utf-8

from . import farmasi
from . import pricelist
