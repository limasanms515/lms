To use this module, you need to:

#. Go to 'Reporting' / 'Custom Reports'

#. Select the desired report

  .. figure:: ../static/description/05_reporting_pivot.png
     :width: 800 px

* You can switch to 'Pie' chart or 'Line Chart' as any report,

  .. figure:: ../static/description/05_reporting_pie.png
     :width: 800 px
