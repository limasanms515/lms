This module allow a user to have Access all operating units (master data)
without having to add OUs in user setting.
