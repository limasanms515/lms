
To configure a user to have access to all operating units:

* Go to *Settings / Users & Companies / Users*
* For a user, select checkbox "Access all Operating Units"
