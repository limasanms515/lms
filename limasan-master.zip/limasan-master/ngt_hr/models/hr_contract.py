
from odoo import models, fields, api, _
from num2words import num2words
from datetime import datetime, time, timedelta


class HrContract(models.Model):
    _inherit = 'hr.contract'


    total_terbilang = fields.Char("Total Terbilang", compute="_get_total_terbilang")
    total_gaji = fields.Monetary("Total Gaji", compute="_get_total_gaji")
    tunjangan = fields.Monetary("Tunjangan")
    date_bilangan = fields.Char("Date Bilangan",compute="_get_date_bilangan")

    @api.depends('date_start')
    def _get_date_bilangan(self):
        for ls in self:
            bulan = datetime.strptime(str(ls.date_start),"%Y-%m-%d").strftime("%B")
            space = ' '
            tanggal = datetime.strptime(str(ls.date_start),"%Y-%m-%d").strftime("%d")
            tahun = datetime.strptime(str(ls.date_start),"%Y-%m-%d").strftime("%Y")
            ls.date_bilangan = num2words(int(tanggal), lang='id').title() + space + str(bulan) + space + num2words(int(tahun), lang='id').title()



    @api.depends('total_gaji')
    def _get_total_terbilang(self):
        for si in self:
            si.total_terbilang = num2words(int(si.total_gaji), lang='id').title() + " Rupiah"

    @api.depends('wage','tunjangan')
    def _get_total_gaji(self):
        for obj in self:
            obj.total_gaji = obj.wage + obj.tunjangan
