{
    "name": "NGT HR",
    "version": "14.0.1.0.0",
    "category": "HR",
    "website": "nusagarda.com",
    "author": "asop-source",
    "depends": ["hr","hr_contract"],
    "data": [
        # 'security/ir.model.access.csv',
        'views/hr_contract.xml',
    ],
}
