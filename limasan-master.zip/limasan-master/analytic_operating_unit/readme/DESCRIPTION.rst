This module allows users to introduce into the analytic accounts the allowed
operating units. Only a user with permissions to operate on the operating
units indicated in an analytic account will have the rights to use it.
