This module allow a user to have Access all OUs' analytic,
without having to add OUs in user setting.
