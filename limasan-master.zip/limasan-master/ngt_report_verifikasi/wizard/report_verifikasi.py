from odoo import api, fields, models, api, _
import xlwt
import base64
from io import BytesIO
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError, Warning
from datetime import date, datetime
import logging
_logger = logging.getLogger(__name__)


class ReportVerifikasi(models.TransientModel):
    _name = "report.verifikasi.wizard"
    _description = "Report verifikasi"




    operating_unit = fields.Many2many('operating.unit',string='Ou')
    date = fields.Date("Date", default=date.today())
    product_name = fields.Char("Product Name", default="Admin Rawat Jalan")
    unit_layanan = fields.Char("Unit Layanan", default="Admin Rawat Jalan")
    product_amount = fields.Integer("Biyaya", default=7000)


    summary_data = fields.Char('Name', size=256)
    file_name = fields.Binary('Report', readonly=True)
    state = fields.Selection([
            ('choose', 'choose'),
            ('get', 'get')],
            default='choose')


    def action_xlwt_report(self):
        file_name = 'Report Klinik .xls'
        workbook = xlwt.Workbook(encoding="UTF-8")
        format0 = xlwt.easyxf(
                'font:height 300,bold True; align: horiz center;'
                )
        formathead2 = xlwt.easyxf(
            'font:height 250,bold True; align: horiz center;'
            )
        format1 = xlwt.easyxf('font: height 240, bold True;pattern: pattern solid, fore_colour gray25;align: horiz left; borders: top_color black, bottom_color black, right_color black, left_color black,\
                         left thin, right thin, top thin, bottom thin;')
        format11 = xlwt.easyxf('font: height 200;')
        format12 = xlwt.easyxf('font: height 240, bold True;pattern: pattern solid, fore_colour gray25;align: horiz center; borders: top_color black, bottom_color black, right_color black, left_color black,\
                         left thin, right thin, top thin, bottom thin;')
        date_format = xlwt.XFStyle()
        date_format.num_format_str = 'dd-mm-yyyy'
        format3 = xlwt.easyxf('align: horiz left; borders: top_color black, bottom_color black, right_color black, left_color black,\
                         left thin, right thin, top thin, bottom thin;')
        sheet = workbook.add_sheet("Report Klinik")
        sheet.col(0).width = int(30 * 260)
        sheet.col(1).width = int(30 * 260)
        sheet.col(2).width = int(40 * 260)
        sheet.col(3).width = int(20 * 260)
        sheet.col(4).width = int(20 * 260)
        sheet.col(5).width = int(30 * 260)
        sheet.col(6).width = int(40 * 260)
        sheet.col(7).width = int(40 * 260)
        sheet.col(8).width = int(40 * 260)
        sheet.col(9).width = int(40 * 260)
        sheet.col(10).width = int(40 * 260)
        sheet.col(11).width = int(40 * 260)
        sheet.col(12).width = int(40 * 260)
        sheet.col(13).width = int(40 * 260)
        sheet.col(14).width = int(40 * 260)
        sheet.col(15).width = int(40 * 260)
        sheet.col(16).width = int(40 * 260)
        sheet.col(17).width = int(40 * 260)
        sheet.row(0).height_mismatch = True
        sheet.row(0).height = 150 * 4
        sheet.row(1).height_mismatch = True
        sheet.row(1).height = 150 * 2
        sheet.row(2).height_mismatch = True
        sheet.row(2).height = 150 * 3
        data = self.read()[0]
        operating_unit = data['operating_unit']
        if not operating_unit:
            raise UserError(_("Ou Tidak Boleh Kosong!"))
        date = datetime.strptime(str(data['date']), '%Y-%m-%d')
        operating = "un.id in %s"%str(
                tuple(operating_unit)).replace(',)', ')')
        query = """
                SELECT 
                    ln.id as id,
                    mv.name as number,
                    res.name as partner,
                    penj.name as penjamin,
                    ln.tanggal_buat as tanggal_buat,
                    ln.tanggal_transaksi as tanggal_transaksi,
                    pend.no_registrasi as pendaftaran,
                    ln.shift as shift,
                    ln.payment_status as payment_status,
                    un.name as ou
                from  tbl_verifikasi_line as ln
                left join account_move as mv
                on ln.invoice_id = mv.id
                left join tbl_pendaftaran as pend
                on mv.pendaftaran_id = pend.id
                left join operating_unit as un
                on ln.ou = un.id
                left join tbl_penjamin as penj
                on ln.penjamin = penj.id
                left join res_partner as res
                on ln.partner = res.id
                where %s
                and ln.tanggal_buat = '%s'
            """%(operating, str(date))
        self._cr.execute(query)
        result = self._cr.dictfetchall()
        row = 0
        col = 0
        sheet.write(row, col, 'Number', format1)
        col += 1
        sheet.write(row, col, 'Partner', format1)
        col += 1
        sheet.write(row, col, 'Penjamin', format1)
        col += 1
        sheet.write(row, col, 'Tanggal Buat', format1)
        col += 1
        sheet.write(row, col, 'Tanggal Transaksi', format1)
        col += 1
        sheet.write(row, col, 'No Registrasi', format1)
        col += 1
        sheet.write(row, col, 'Shift', format1)
        col += 1
        sheet.write(row, col, 'Payment Status', format1)
        col += 1
        sheet.write(row, col, 'ou', format1)
        col += 1
        sheet.write(row, col, 'Nama Produk', format1)
        col += 1
        sheet.write(row, col, 'Produk Kategori', format1)
        col += 1
        sheet.write(row, col, 'Unit Layanan', format1)
        col += 1
        sheet.write(row, col, 'Sub Total', format1)
        col += 1
        sheet.write(row, col, 'Jurnal', format1)
        col += 1
        sheet.write(row, col, 'Nama Dokter', format1)
        col += 1
        sheet.write(row, col, 'Penerimaan', format1)
        col += 1
        sheet.write(row, col, 'Kasir/KASIR', format1)
        col += 1
        sheet.write(row, col, 'Discount', format1)
        col += 1
        sheet.write(row, col, 'Keterangan', format1)
        col = 0
        row += 1
        obj = []
        for res in result:
            verifikasi = self.env['tbl_verifikasi_line'].search([
                ('id','=',res['id'])])
            sub_total = 0
            if verifikasi.product_category:
                pemeriksa = verifikasi.filtered(lambda l: l.product_category.name[:11] == "Pemeriksaan" and verifikasi.sub_total == 150000 or l.product_category.name[:11] == "Pemeriksaan" and verifikasi.sub_total == 50000 or verifikasi.product_category.name[:11] == "Pemeriksaan" and verifikasi.sub_total == 55000)
                biyaya = {
                        'number': res['number'],
                        'partner': res['partner'],
                        'penjamin': res['penjamin'],
                        'tanggal_buat': res['tanggal_buat'],
                        'tanggal_transaksi': res['tanggal_transaksi'],
                        'pendaftaran': res['pendaftaran'],
                        'shift': res['shift'],
                        'payment_status': res['payment_status'],
                        'ou': res['ou'],
                        'product': self.product_name,
                        'product_category': verifikasi.product_category.name,
                        'unit_layanan': self.unit_layanan,
                        'sub_total': self.product_amount,
                        'journal': verifikasi.journal_id.name  if verifikasi.journal_id else " ",
                        'nama_dokter': verifikasi.nama_dokter.name  if verifikasi.nama_dokter else " ",
                        'cash_penerimaan': verifikasi.cash_penerimaan,
                        'report_shif': verifikasi.report_shift_id.name.name,

                        }
                if pemeriksa:
                    sub_total = (verifikasi.sub_total + verifikasi.invoice_id.discount) - self.product_amount
                    obj.append(biyaya)
                else:
                    sub_total = verifikasi.sub_total + verifikasi.invoice_id.discount
                    
            sheet.write(row, col, res['number'], format11)
            col += 1
            sheet.write(row, col, res['partner'], format11)
            col += 1
            sheet.write(row, col, res['penjamin'], format11)
            col += 1
            sheet.write(row, col, res['tanggal_buat'], date_format)
            col += 1
            sheet.write(row, col, res['tanggal_transaksi'], date_format)
            col += 1
            sheet.write(row, col, res['pendaftaran'], format11)
            col += 1
            sheet.write(row, col, res['shift'], format11)
            col += 1
            sheet.write(row, col, res['payment_status'], format11)
            col += 1
            sheet.write(row, col, res['ou'], format11)
            col += 1
            sheet.write(row, col, verifikasi.product.name, format11)
            col += 1
            sheet.write(row, col, verifikasi.product_category.name, format11)
            col += 1
            sheet.write(row, col, verifikasi.unit_layanan.name if verifikasi.unit_layanan else " ", format11)
            col += 1
            sheet.write(row, col, sub_total, format11)
            col += 1
            sheet.write(row, col, verifikasi.journal_id.name if verifikasi.journal_id else " ", format11)
            col += 1
            sheet.write(row, col, verifikasi.nama_dokter.name if verifikasi.nama_dokter else " ", format11)
            col += 1
            sheet.write(row, col, verifikasi.cash_penerimaan, format11)
            col += 1
            sheet.write(row, col, verifikasi.report_shift_id.name.name if verifikasi.report_shift_id else " ", format11)
            col += 1
            sheet.write(row, col, verifikasi.invoice_id.discount if verifikasi.invoice_id.discount > 0 else " ", format11)
            col += 1
            sheet.write(row, col, 'Discount', format11)
            col = 0
            row += 1

        col = 0
        for res in obj:
            sheet.write(row, col, res['number'], format11)
            col += 1
            sheet.write(row, col, res['partner'], format11)
            col += 1
            sheet.write(row, col, res['penjamin'], format11)
            col += 1
            sheet.write(row, col, res['tanggal_buat'], date_format)
            col += 1
            sheet.write(row, col, res['tanggal_transaksi'], date_format)
            col += 1
            sheet.write(row, col, res['pendaftaran'], format11)
            col += 1
            sheet.write(row, col, res['shift'], format11)
            col += 1
            sheet.write(row, col, res['payment_status'], format11)
            col += 1
            sheet.write(row, col, res['ou'], format11)
            col += 1
            sheet.write(row, col, res['product'], format11)
            col += 1
            sheet.write(row, col, res['product_category'], format11)
            col += 1
            sheet.write(row, col, res['unit_layanan'], format11)
            col += 1
            sheet.write(row, col, res['sub_total'], format11)
            col += 1
            sheet.write(row, col, res['journal'], format11)
            col += 1
            sheet.write(row, col, res['nama_dokter'] , format11)
            col += 1
            sheet.write(row, col, res['cash_penerimaan'], format11)
            col += 1
            sheet.write(row, col, res['report_shif'], format11)
            col += 1
            sheet.write(row, col, 0, format11)
            col += 1
            sheet.write(row, col, ' ', format11)
            col = 0
            row += 1


        fp = BytesIO()
        workbook.save(fp)
        self.write(
        {'state': 'get', 'file_name': base64.encodebytes(fp.getvalue()), 'summary_data': file_name})
        fp.close()
        return {
            'type': 'ir.actions.act_window',
            'res_model': 'report.verifikasi.wizard',
            'view_mode': 'form',
            'view_type': 'form',
            'res_id': self.id,
            'target': 'new',
        }
