{
    "name": "Report Layanan",
    "version": "14.0.1.0.0",
    "category": "RMA",
    "website": "nusagarda.com",
    "author": "asop-source",
    "depends": ["bisa_verifikasi"],
    "data": [
        'security/ir.model.access.csv',
        'wizard/report_verifikasi.xml',
        'wizard/report_klinik.xml',
        'wizard/menu.xml',
    ],
}
