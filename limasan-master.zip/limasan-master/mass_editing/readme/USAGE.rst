* *Go for Mass Editing*: select the records which you want to modify and click on *Action* to open mass editing popup.

.. image:: ../static/description/mass_editing-item_tree.png
   :width: 70%

* Select *Set / Remove* action and write down the value to set or remove the value for the given field.

.. image:: ../static/description/mass_editing-wizard_form.png
   :width: 70%

* This way you can set / remove the values of the fields.

.. image:: ../static/description/mass_editing-item_tree-result.png
   :width: 70%
