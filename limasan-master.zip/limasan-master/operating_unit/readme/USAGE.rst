
This module defines the operating unit entity and the user's security rules.
Other modules extend the standard Odoo apps with the OU.
