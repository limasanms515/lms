{
    'name': 'Global Discount By J8C',
    'version': '18.06.2021',
    'summary': """Sales Global Discount""",
    'description': 'Sales Global Discount',
    "category": "Sale",
    "author": "J8C",
    'depends': ['sale'],
    'data': [
        'views/sale_views.xml',
    ],
    'license': 'AGPL-3',
    'demo': [],
    "images": ['static/description/img-3.png'],
    'installable': True,
    'auto_install': False,
    'application': False,
}
