
from odoo import api, fields, models, api, _
import logging
_logger = logging.getLogger(__name__)


class RegisterPayments(models.TransientModel):
	_inherit = 'account.payment.register'
	_description = 'Register'




	def _create_payments(self):
		payments = super(RegisterPayments, self)._create_payments()
		for x in payments.reconciled_invoice_ids:
			report = self.env['tbl_report_detail_invoice_line'].search([('memo','=', x.name)])
			for line in report:
				if line:
					line.journal_id = payments.journal_id.id
			payments.move_name = x.id
		return payments