


from odoo import api, fields, models, SUPERUSER_ID, _


class tbl_rs_sarana(models.Model):
    _inherit = 'account.payment'
    _description = "Account Payment"


    move_name = fields.Many2one("account.move","Invoices", store=True)


    # @api.depends('reconciled_invoice_ids')
    # def get_update_invoce(self):
    #     for line in self:
    #         recon = line.reconciled_invoice_ids.id
    #         line.move_name = recon
