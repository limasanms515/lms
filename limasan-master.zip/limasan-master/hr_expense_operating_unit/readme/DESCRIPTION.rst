This module introduces the following features:

* Adds the Operating Unit (OU) to the Expense.

* Security rules are defined to ensure that users can only see the Expense of that Operating Units in which they are allowed access to.

* Adds Operating Unit (OU) to the account moves while generating accounting entries from the expense.
