To use this module create the Operating Unit or use a created one:

#. Once you have an OU, make sure you assign it to the desired User.
#. Create the expense with the OU.
#. The selectable OU are filtered by the users OU's.
