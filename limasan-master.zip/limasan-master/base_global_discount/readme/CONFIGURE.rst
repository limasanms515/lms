To use this module, you need to:

#. Go to *Settings > Users*, choose yours and set *Manage Global Discounts*.
#. Go to *Settings > Parameters > Global Discounts*
#. Choose the discount scope (sales or purchases).
#. You can also restrict it to a certain company if needed.
