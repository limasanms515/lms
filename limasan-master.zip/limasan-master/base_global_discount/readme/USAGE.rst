You can assign global discounts to partners as well. You'll need the proper
permission (*Manage Global Discounts*):

#. Go to a partner that is a company.
#. Go to the *Sales & Purchases* tab.
#. In section sale, you can set sale discounts.
#. In section purchase, you can set purchase discounts.
