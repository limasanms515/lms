from . import global_discount
from . import res_partner
